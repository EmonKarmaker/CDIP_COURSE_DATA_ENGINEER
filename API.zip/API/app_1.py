from fastapi import FastAPI, Query

app = FastAPI()

# Updated sample data based on the screenshot
ads_data = {
    "16B": {
        "heading": "Moderne & stilren bolig fra 2017 - på Øvre Lande. Store rom, garasje og god tilgang på sol & lys!",
        "price": "5 490 000 kr",
    }
}

@app.get("/ad-details")
def get_ad_details(finn_code: str = Query(..., description="The FINN code of the ad")):
    """
    Fetch ad details based on the given FINN code.
    """
    ad = ads_data.get(finn_code)
    if ad:
        return {"heading": ad["heading"], "price": ad["price"]}
    return {"error": "Ad not found. Please check the FINN code."}
